<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class disponibilidad extends Model
{
    protected $table ='disponibilidads';

    public $primaryKey='id';


}
