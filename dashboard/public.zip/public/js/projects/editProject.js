/**Function to calculate profid and total sold */
function cal() {
    try {
      var a = parseFloat(document.form1.budgetProject.value),
          b = parseFloat(document.form1.soldProject.value); 
          if (b==0){
            document.form1.totalProject.value = "$" + 0.00.toFixed(2);
            document.form1.profitProject.value = 0.00.toFixed(2) + "%";
          }else{
            var total =  b - a;
            var percent =  ((b - a)*100)/b;
            document.form1.totalProject.value = "$" + total.toFixed(2);
            document.form1.profitProject.value = percent.toFixed(2) + "%";
          }
    } catch (e) {
    }
  }

  $( document ).ready(function() {
    cal();
  });
  
  
  