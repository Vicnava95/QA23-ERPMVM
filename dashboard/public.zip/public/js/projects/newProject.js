/**Function to calculate profif and total sold */
function cal() {
  try {
    var a = parseFloat(document.form1.budgetProject.value),
        b = parseFloat(document.form1.soldProject.value); 
        if (b==0){
          document.form1.totalProject.value = "$" + 0.00.toFixed(2);
          document.form1.profitProject.value = 0.00.toFixed(2) + "%";
        }else{
          var total =  b - a;
          var percent =  ((b - a)*100)/b;
          document.form1.totalProject.value = "$" + total.toFixed(2);
          document.form1.profitProject.value = percent.toFixed(2) + "%";
        }
  } catch (e) {
  }
}


var contadorC = 0;
var contadorP = 0;
var contadorF = 0;

/** Contador contactos  */
function countContacts(){
  var c = ++contadorC;
  console.log(c);
  return c
} 
/** Contador de Phases */
function countPhases(){
  var p = ++contadorP;
  console.log(p);
  return p
}
/** Contador de files */
function countFiles(){
  var f = ++contadorF;
  console.log(f);
  return f
}

function deleteContact(id){
  $('#container-'+id).remove();
}

function deletePhase(id){
  $('#containerP-'+id).remove();
}

function deleteFile(id){
  $('#containerF-'+id).remove();
}

/********************************************************************* */
$( document ).ready(function() {

  $('.date2').hide();
  $('#budgetProject').val(0);
  $('#soldProject').val(0);
  cal();
  $('#phaseNameProject').val('Empty');
  $('#phaseTextProject').val('Empty');
  $('#phaseBudgetProject').val(0);
/*   $('#dirtTruck').val(0);
  $('#concreteTruckt').val(0);
  $('#mixedTruck').val(0); */
  $('#note').val('Empty');

/**Function to add and delete more Contacts */
  $('.addRowContact').on('click',function(){
    
    addRowContact(countContacts());
  });

  function addRowContact(id){
    var tr =   '<div id="container-'+id+'">'+
                '<div class="row" id="row">'+
                  '<div class="col">'+
                      '<label style="font-size: 12px;">Name</label>'+
                      '<input type="text" class="form-control form-control-sm" id="nameContact" name="name[]" autocomplete="off">'+
                  '</div>'+
                  '<div class="col">'+
                      '<label style="font-size: 12px;">Phone</label>'+
                      '<input type="text" class="form-control form-control-sm" id="phoneContact" name="phone[]" autocomplete="off">'+
                  '</div>'+
                '</div>'+
                '<span class="badge badge-danger" onclick="deleteContact('+id+')" style="font-size: 10px; margin: 10px 0px 10px 0px; cursor: pointer;"  href="#addContact" role="button" aria-expanded="false" aria-controls="collapseExample">Delete</span>'+
                '</div>';
            $('.rowcontact').append(tr);
  } 

  /****************************************************************** */

  /**Function to add and delete more Phases */
  $('.addRowPhases').on('click',function(){
    addRowPhases(countPhases());
    //alert("hola");
  });
  
  function addRowPhases(id){
    var ph = '<div id="containerP-'+id+'">'+
            '<div class="row">'+
              '<div class="col-xs-12 col-md-6">'+
                '<div class="form-group">'+
                    '<label style="font-size: 12px;">Phase Name</label>'+
                    '<input type="text" class="form-control form-control-sm" maxlength="100" id="phaseNameProject'+id+'" name="phaseNameProject[]" placeholder="" required>'+
                '</div>'+
              '</div>'+
              '<div class="col-xs-12 col-md-6">'+
                '<div class="form-group">'+
                    '<label style="font-size: 12px;">Budget</label>'+
                    '<input type="number" min="0" step="0.01" class="form-control form-control-sm" id="phaseBudgetProject'+id+'" name="phaseBudgetProject[]" placeholder="" required>'+
                '</div>'+
              '</div>'+
            '</div>'+
            '<div class="form-group">'+
                '<label style="font-size: 12px;">Text</label>'+
                '<textarea type="text" class="form-control form-control-sm" rows="3" id="phaseTextProject'+id+'" name="phaseTextProject[]" placeholder="" required></textarea>'+
            '</div>'+
            
            /* '<div class="form-group">'+
                '<label style="font-size: 12px;">Dirt Truck Estimate</label>'+
                '<input type="number" class="form-control form-control-sm" id="dirtTruck" name="dirtTruck[]" min="0" value="0" step="0.01" placeholder="" required>'+
            '</div>'+
            '<div class="form-group">'+
                '<label style="font-size: 12px;">Concrete Truck Estimate</label>'+
                '<input type="number" class="form-control form-control-sm" id="concreteTruck" name="concreteTruck[]" min="0" value="0" step="0.01" placeholder="" required>'+
            '</div>'+
            '<div class="form-group">'+
                '<label style="font-size: 12px;">Mixed Truck Estimate</label>'+
                '<input type="number" class="form-control form-control-sm" id="mixedTruck" name="mixedtruck[]" min="0" value="0" step="0.01" placeholder="" required>'+
            '</div>'+ */
            '<span class="badge badge-danger" style="font-size: 10px; cursor: pointer;"  onclick="deletePhase('+id+')" href="#addPhase" role="button" aria-expanded="false" aria-controls="collapseExample">Delete</span>'+
            '<hr>'+
            '</div>';
            $('.rowPhases').append(ph);
            $('#phaseNameProject'+id).val('Empty');
            $('#phaseTextProject'+id).val('Empty');
            $('#phaseBudgetProject'+id).val(0);
            /* $('#dirtTruck').val(0);
            $('#concreteTruckt').val(0);
            $('#mixedTruck').val(0); */
  } 


  /****************************************************************** */

  /**Function to add and delete more FileUpload Buttons */
  $('.addRowButtons').on('click',function(){
    addRowButtons(countFiles());
    console.log("hola");
  });

  function addRowButtons(id){
    var bt = 
    '<div id="containerF-'+id+'" >'+
      '<div class="form-group" style="margin:0px;">'+
      '<div class="file-select" id="src-file1" >'+
        '<input type="file" aria-label="Archivo" name="myfile[]">'+
      '</div>'+
      '</div>'+
      '<span class="badge badge-danger" onclick="deleteFile('+id+')" style="font-size: 10px; margin: 10px 0px 10px 0px; cursor: pointer;"  href="#addPhase" role="button" aria-expanded="false" aria-controls="collapseExample">Delete</span>'+
    '</div>';
    $('.rowButtons').append(bt);
  } 
});


