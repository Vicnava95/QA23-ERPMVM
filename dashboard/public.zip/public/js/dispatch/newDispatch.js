
$(document).ready(function(){
    //Funcción para asignarle el precio a la máquina escogida
    $("select.machinery1").change(function(){
        var idMachinery1 = $(this).children("option:selected").attr("id");
        //alert(idMachinery1)
        switch (idMachinery1){
            case 'ME303_001':
                //250
                $('#priceEquip1').val(250);
                break;
            case 'ME304_001':
                //300
                $('#priceEquip1').val(300);
                break;
            case 'RTSC2_001':
                //180
                $('#priceEquip1').val(180);
                break;
            case 'SSL232_001':
                //200
                $('#priceEquip1').val(200);
                break;
            case 'SSL262_001': 
                //250
                $('#priceEquip1').val(250);
                break;
            case 'SSTL259_001':
                //275
                $('#priceEquip1').val(275);
                break;
            default:
                $('#priceEquip1').val("");
        }
        var val1 = parseFloat($('#priceEquip1').val());
        var val2 = parseFloat($('#priceEquip2').val());
        var v1 = validateVal1(val1);
        var v2 = validateVal2(val2);
        $('#rentalCost').val( v1 + v2);;
    });

/*     //Funcción para asignarle el precio a la máquina escogida
    $("select.machinery2").change(function(){
        var idMachinery2 = $(this).children("option:selected").attr("id");
        //alert(idMachinery2)
        switch (idMachinery2){
            case 'ME303_001':
                //250
                $('#priceEquip2').val(250);
                break;
            case 'ME304_001':
                //300
                $('#priceEquip2').val(300);
                break;
            case 'RTSC2_001':
                //180
                $('#priceEquip2').val(180);
                break;
            case 'SSL232_001':
                //200
                $('#priceEquip2').val(200);
                break;
            case 'SSL262_001': 
                //250
                $('#priceEquip2').val(250);
                break;
            case 'SSTL259_001':
                //275
                $('#priceEquip2').val(275);
                break;
            default:
                $('#priceEquip2').val("");
        }
        var val1 = parseFloat($('#priceEquip1').val());
        var val2 = parseFloat($('#priceEquip2').val());
        var v1 = validateVal1(val1);
        var v2 = validateVal2(val2);
        $('#rentalCost').val( v1 + v2);
    }); */

    $("input#priceEquip1").change(function(){
        var val1 = parseFloat($('#priceEquip1').val());
        var val2 = parseFloat($('#priceEquip2').val());
        var v1 = validateVal1(val1);
        var v2 = validateVal2(val2);
        $('#rentalCost').val( v1 + v2);
    });

    $("input#priceEquip2").change(function(){
        var val1 = parseFloat($('#priceEquip1').val());
        var val2 = parseFloat($('#priceEquip2').val());
        var v1 = validateVal1(val1);
        var v2 = validateVal2(val2);
        $('#rentalCost').val( v1 + v2);
    });

    function validateVal1(val1){
        var valor = 0;
        if (!val1 || /^\s*$/.test(val1)){
            valor = 0;
        }else{
            valor = val1;
        }
        console.log('valor 1'+" = "+ valor)
        return valor; 
    }
    function validateVal2(val2){
        var valor2 = 0;
        if (!val2 || /^\s*$/.test(val2)){
            valor2 = 0;
        }else{
            valor2 = val2;
        }
        console.log('valor2'+" = "+ valor2);
        return valor2;
    }
});