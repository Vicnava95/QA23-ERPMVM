<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Vista ejemplo</title>
</head>
<body>
    <h1>Hola mundo desde Laravel</h1>
</body>
</html><?php /**PATH C:\Users\josep\php_proyect\mvmplatform\MVM\resources\views/saludo.blade.php ENDPATH**/ ?>