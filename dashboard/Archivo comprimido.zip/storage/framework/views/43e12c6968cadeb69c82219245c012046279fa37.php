<!doctype html>
<html>
 <body>
   <form method='post' action='/save'>

     <!-- Message -->
     <?php if(Session::has('message')): ?>
       <p ><?php echo e(Session::get('message')); ?></p>
     <?php endif; ?>

     <!-- Add/List records -->
     <table border='1' style='border-collapse: collapse;'>
       <tr>
         <th>Username</th>
         <th>Name</th>
         <th>Email</th>
         <th></th>
       </tr>
       <tr>
         <td colspan="4"><?php echo e(csrf_field()); ?></td>
       </tr>
       <!-- Add -->
       <tr>
         <td><input type='text' name='username'></td>
         <td><input type='text' name='name'></td>
         <td><input type='email' name='email'></td>
         <td><input type='submit' name='submit' value='Add'></td>
       </tr>

       <!-- List -->
       
    </table>
  </form>

  
 
 </body>
</html><?php /**PATH C:\Users\josep\php_proyect\MVM\resources\views/example.blade.php ENDPATH**/ ?>